# Placement Cell WEB App

### Users and workers can manage student interviews and assign students to company interviews using the placement cell web application.
### It is built on JavaScript, NodeJs, ExpressJs, MongoDB, and EJS.


### Hosted Link: [Placement Cell](http://ec2-44-204-180-25.compute-1.amazonaws.com/)

### Screenshots

![image](https://user-images.githubusercontent.com/36923392/201409827-7a29cad5-ac1e-417b-a8d5-ad9e76fa2f78.png)

![image](https://user-images.githubusercontent.com/36923392/201409880-efb6c73e-f07a-4368-bc9b-1f5c11f5d980.png)

![image](https://user-images.githubusercontent.com/36923392/201414124-be04d0f3-332b-42e9-a95a-ad1e1be6b907.png)

![image](https://user-images.githubusercontent.com/36923392/201414167-789a4e3a-277a-46b6-8f29-2037ba28caf4.png)


